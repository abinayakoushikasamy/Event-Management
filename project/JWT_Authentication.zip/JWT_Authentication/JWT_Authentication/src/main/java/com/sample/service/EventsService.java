package com.sample.service;

import com.sample.entity.Events;
import com.sample.repository.EventsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EventsService {

    private final EventsRepository eventsRepository;

    @Autowired
    public EventsService(EventsRepository eventsRepository) {
        this.eventsRepository = eventsRepository;
    }

    public List<Events> getAllEvents() {
        return eventsRepository.findAll();
    }

    public Events getEventById(Long id) {
        Optional<Events> event = eventsRepository.findById(id);
        return event.orElse(null);
    }

    public Events updateEvent(Long id, Events updatedEvent) {
        Optional<Events> optionalExistingEvent = eventsRepository.findById(id);
        if (optionalExistingEvent.isPresent()) {
            Events existingEvent = optionalExistingEvent.get();
            existingEvent.setEventName(updatedEvent.getEventName());
            existingEvent.setTiming(updatedEvent.getTiming());
            existingEvent.setDate(updatedEvent.getDate());
            existingEvent.setPeoplecount(updatedEvent.getPeoplecount());
            return eventsRepository.save(existingEvent);
        }
        return null;
    }

    public void deleteEvent(Long id) {
        eventsRepository.deleteById(id);
    }

    public Events createEvent(Events event) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'createEvent'");
    }
}
