package com.sample.controller;

import com.sample.entity.Events;
import com.sample.service.EventsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/eventss")
@CrossOrigin(origins="*")
public class EventsController {

    private final EventsService eventsService;

    @Autowired
    public EventsController(EventsService eventsService) {
        this.eventsService = eventsService;
    }

    @GetMapping("/{id}")
    public Events getEventById(@PathVariable Long id) {
        return eventsService.getEventById(id);
    }

    @PutMapping("/{id}")
    public Events updateEvent(@PathVariable Long id, @RequestBody Events event) {
        return eventsService.updateEvent(id, event);
    }

    @DeleteMapping("/{id}")
    public void deleteEvent(@PathVariable Long id) {
        eventsService.deleteEvent(id);
    }

    @GetMapping
    public List<Events> getAllEvents() {
        return eventsService.getAllEvents();
    }

    @PostMapping("/addsss")
    public Events createEvent(@RequestBody Events event) {
        return eventsService.createEvent(event);
    }
}
