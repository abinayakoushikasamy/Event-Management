package com.sample.entity;

public class Login {
    
}
