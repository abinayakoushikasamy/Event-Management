package com.sample.repository;

public class LoginRepository {
    
}
