package com.sample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.entity.Event;
import com.sample.entity.Events;


public interface EventsRepository extends JpaRepository<Events, Long> {

}
 