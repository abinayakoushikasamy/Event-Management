package com.sample.service;

public class LoginService {
    
}
