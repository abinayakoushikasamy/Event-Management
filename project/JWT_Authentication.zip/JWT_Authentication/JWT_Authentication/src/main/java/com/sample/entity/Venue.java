package com.sample.entity;

public class Venue {
    
}
